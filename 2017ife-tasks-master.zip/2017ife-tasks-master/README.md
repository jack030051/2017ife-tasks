# 2017ife-tasks
<<<<<<< HEAD
The purpose for creating the branch is to upload the work of the tasks of IFE in 2017, and then wish me would complete all the tasks.

I wish the tasks would be handled easily.

I love :coffee:.
=======
2017年百度前端学院任务正在进行时
>>>>>>> 2a4f2e2f985b7b8654068f6a6d5cf653099b2291
